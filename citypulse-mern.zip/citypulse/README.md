# CityPulse — Smart City Issue Reporting Dashboard

A full-stack MERN application for reporting, tracking, and resolving civic issues. The reference URL was checked, but its UI could not be inspected by the text browser; this implementation uses a modern civic-operations dashboard as a fallback rather than claiming a pixel-perfect copy.

## Requirements
- Node.js 20 LTS or newer (Node 20/22 recommended)
- MongoDB local service or MongoDB Atlas connection
- npm

## Quick start
1. Install dependencies from the repository root: `npm run install:all`
2. Copy `backend/.env.example` to `backend/.env` and set `MONGODB_URI` and a long random `JWT_SECRET`.
3. Copy `frontend/.env.example` to `frontend/.env` (defaults work for local development).
4. Start MongoDB.
5. Seed sample data: `npm run seed`
6. Start both applications: `npm run dev`
7. Open the Vite URL shown in the terminal (normally `http://localhost:5173`). API health check: `http://localhost:5000/api/health`.

### Demo accounts (local seed only)
- Admin: `admin@citypulse.local` / `CityPulse123!`
- Staff: `staff@citypulse.local` / `CityPulse123!`
- Citizen: `citizen@citypulse.local` / `CityPulse123!`

Change or remove these accounts before deploying. Never use seeded credentials in production.

## Environment
See `backend/.env.example` and `frontend/.env.example`. Keep secrets out of source control. `JWT_SECRET` must be unique and strong. Set `CLIENT_ORIGIN` to your deployed frontend origin in production.

## Main features
- JWT authentication, bcrypt password hashes, citizen/staff/admin roles
- Issue CRUD, assignment, validated status transitions and status history
- Server-side search, filtering, sorting and pagination
- Category and location CRUD for admins, with delete protection when referenced
- Dashboard summary and chart data aggregated from MongoDB
- Local image upload with MIME and size validation
- Responsive dashboard, issue table, forms, charts and reusable feedback states

## API overview
All endpoints are prefixed with `/api`. Auth: `/auth`; issues: `/issues`; categories: `/categories`; locations: `/locations`; dashboard: `/dashboard`. Full endpoint list is in `docs/API_DOCUMENTATION.md`.

## Production notes
Build frontend with `npm run build`. Deploy `frontend/dist` to a static host and deploy the backend separately. Configure MongoDB Atlas, `CLIENT_ORIGIN`, `JWT_SECRET`, and `UPLOAD_DIR`. For production image storage, replace the local Multer destination with Cloudinary/S3. Use HTTPS and secure cookie/token policies appropriate to your deployment. This project uses bearer tokens stored in sessionStorage for a straightforward local demo; for higher-security production deployments, consider HttpOnly secure cookies and CSRF protections.

## Troubleshooting
- Mongo connection failure: confirm MongoDB is running and `MONGODB_URI` is correct.
- CORS errors: set `CLIENT_ORIGIN` to the exact frontend origin, including port.
- Missing images: ensure `backend/uploads` exists and the API server can write to it.
- Port conflicts: change `PORT` in backend `.env` and `VITE_API_URL` in frontend `.env` together.
