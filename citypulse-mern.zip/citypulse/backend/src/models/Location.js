import mongoose from 'mongoose';
const schema = new mongoose.Schema({ name:{type:String,required:true,trim:true,maxlength:100}, address:{type:String,trim:true,maxlength:250}, coordinates:{latitude:{type:Number,min:-90,max:90},longitude:{type:Number,min:-180,max:180}}, active:{type:Boolean,default:true} },{timestamps:true});
schema.index({name:1,address:1},{unique:true});
export default mongoose.model('Location',schema);
