import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ['Citizen','Staff','Admin'], default: 'Citizen', index: true },
  phone: { type: String, trim: true, maxlength: 25 },
  profileImage: String
}, { timestamps: true });
export default mongoose.model('User', userSchema);
