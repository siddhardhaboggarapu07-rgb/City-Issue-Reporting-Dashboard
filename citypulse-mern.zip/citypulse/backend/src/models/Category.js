import mongoose from 'mongoose';
const schema = new mongoose.Schema({ name:{type:String,required:true,trim:true,unique:true,maxlength:80}, description:{type:String,trim:true,maxlength:300}, icon:{type:String,default:'circle-help'}, active:{type:Boolean,default:true} },{timestamps:true});
export default mongoose.model('Category',schema);
