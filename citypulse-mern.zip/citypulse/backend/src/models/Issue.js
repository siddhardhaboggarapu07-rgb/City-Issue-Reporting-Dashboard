import mongoose from 'mongoose';
const historySchema = new mongoose.Schema({ previousStatus:{type:String}, newStatus:{type:String,required:true}, changedBy:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true}, note:{type:String,trim:true,maxlength:500}, changedAt:{type:Date,default:Date.now} },{_id:false});
const schema = new mongoose.Schema({
 title:{type:String,required:true,trim:true,minlength:4,maxlength:140,index:'text'}, description:{type:String,required:true,trim:true,minlength:10,maxlength:5000},
 category:{type:mongoose.Schema.Types.ObjectId,ref:'Category',required:true,index:true}, location:{type:mongoose.Schema.Types.ObjectId,ref:'Location',required:true,index:true}, address:{type:String,trim:true,maxlength:250}, coordinates:{latitude:{type:Number,min:-90,max:90},longitude:{type:Number,min:-180,max:180}},
 priority:{type:String,enum:['Low','Medium','High','Critical'],default:'Medium',index:true}, status:{type:String,enum:['Reported','Acknowledged','In Progress','Resolved','Closed'],default:'Reported',index:true},
 image:{url:String,filename:String,mimetype:String,size:Number}, reportedBy:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true}, assignedTo:{type:mongoose.Schema.Types.ObjectId,ref:'User',default:null,index:true}, history:[historySchema]
},{timestamps:true});
schema.index({createdAt:-1}); schema.index({status:1,priority:1,createdAt:-1});
export default mongoose.model('Issue',schema);
