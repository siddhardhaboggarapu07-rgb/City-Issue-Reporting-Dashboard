import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
const uploadDir=path.resolve(process.cwd(),process.env.UPLOAD_DIR||'uploads'); fs.mkdirSync(uploadDir,{recursive:true});
const storage=multer.diskStorage({destination:(req,file,cb)=>cb(null,uploadDir),filename:(req,file,cb)=>cb(null,`${Date.now()}-${Math.round(Math.random()*1e9)}${path.extname(file.originalname).toLowerCase()}`)});
const allowed=new Set(['image/jpeg','image/png','image/webp','image/gif']);
export const upload=multer({storage,limits:{fileSize:Number(process.env.MAX_FILE_SIZE_MB||5)*1024*1024,files:1},fileFilter:(req,file,cb)=>allowed.has(file.mimetype)?cb(null,true):cb(Object.assign(new Error('Only JPEG, PNG, WEBP, or GIF images are allowed'),{statusCode:400}))});
