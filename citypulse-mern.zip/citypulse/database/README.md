Run `npm run seed` from the repository root after configuring `backend/.env`. The script upserts deterministic demo users, categories, locations, and issues; it does not clear existing data.
