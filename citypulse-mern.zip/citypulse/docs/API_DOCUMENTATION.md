# CityPulse API
Base URL: `http://localhost:5000/api`. JSON endpoints use `{message}` for errors. Protected routes require `Authorization: Bearer <token>`.

## Auth
- `POST /auth/register` — `{name,email,password}`; new users are Citizens.
- `POST /auth/login` — `{email,password}`; returns `{token,user}`.
- `POST /auth/logout` — authenticated client logout acknowledgement.
- `GET /auth/me` — current user.
- `PUT /auth/profile` — update `name` and/or `phone`.

## Issues (authenticated)
- `GET /issues` — query `search,status,category,location,priority,from,to,sort=newest|oldest|priority,page,limit`; returns `{items,total,page,limit,pages}`.
- `POST /issues` — multipart form fields `title,description,category,location,priority,address,latitude,longitude,image`.
- `GET /issues/:id` — issue detail and history.
- `PUT /issues/:id` — edit fields; reporters can edit their own issues, staff their assigned issues, admins all.
- `PATCH /issues/:id/status` — `{status,note}`; Staff/Admin only. Transitions are validated.
- `DELETE /issues/:id` — reporter or Admin.

## Categories and locations
For both `/categories` and `/locations`: `GET /`, `GET /:id` authenticated; `POST /`, `PUT /:id`, `DELETE /:id` Admin-only. Deletion is blocked if referenced by an issue. Category body: `{name,description,icon,active}`. Location body: `{name,address,coordinates:{latitude,longitude},active}`.

## Dashboard
All authenticated: `GET /dashboard/summary`, `/issues-over-time`, `/issues-by-category`, `/issues-by-status`, `/issues-by-location`, `/recent`. Data is aggregated from MongoDB and scoped to the user's visibility.

## Security/validation
Rate limiting applies to `/auth`; uploads accept JPEG, PNG, WEBP and GIF up to `MAX_FILE_SIZE_MB`; role and ownership checks run server-side. Use HTTPS and a strong `JWT_SECRET` in production.
