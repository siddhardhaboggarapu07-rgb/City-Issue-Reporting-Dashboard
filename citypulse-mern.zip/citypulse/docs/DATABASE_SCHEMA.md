# Database schema

- **User**: name, unique normalized email, passwordHash (excluded by default), role (`Citizen|Staff|Admin`), phone, profileImage, timestamps.
- **Category**: unique name, description, icon, active, timestamps.
- **Location**: name, address, optional latitude/longitude, active, timestamps; compound unique index on name/address.
- **Issue**: title, description, category and location references, optional address/coordinates, priority (`Low|Medium|High|Critical`), status (`Reported|Acknowledged|In Progress|Resolved|Closed`), image metadata, reporter and assignee references, status history, timestamps.

Indexes cover issue text search, status/priority/createdAt, createdAt, category, location, reporter and assignee. Dashboard aggregations join categories/locations at query time. Category/location deletion is refused while referenced.
